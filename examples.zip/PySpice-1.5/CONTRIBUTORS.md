# Contributors

In addition to https://github.com/FabriceSalvaire/PySpice/graphs/contributors, some contributors are lost due to git/github folks ...

* **Peter Garrone** https://github.com/PeterGarrone

  Pole-zero, noise, distorsion, transfer-function analyses

  https://github.com/FabriceSalvaire/PySpice/pull/191 merged in 7aea62b (author lost in github)
