This example comes from https://github.com/stffrdhrn/kicad-spice-demo

Note: We have to prexix manually Ji by X.
