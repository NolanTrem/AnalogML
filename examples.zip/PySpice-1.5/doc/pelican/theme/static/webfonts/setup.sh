for i in ../../node_modules/@fortawesome/fontawesome-free/webfonts/* ; do ln -sf $i; done
