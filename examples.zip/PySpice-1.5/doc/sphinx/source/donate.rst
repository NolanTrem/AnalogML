.. _donate-page:

=======================
 How to Help Further ?
=======================

If you like PySpice, you can donate for its developement to my `PayPal account
<https://www.paypal.me/FabriceSalvaire>`_.

This budget could help me to mainly finance a domain, a vps to host a site, a forum (*) and also to
participate to conference on open source Electronic Design Automation.

(*) This web site is actually hosted on my vps, which is quite loaded.  I don't use hosting site
since it is easier to update the documentation using my own infrastructure.

Professional Support
====================

PySpice is provided as is and I don't provide extensive support.  I just solve issues and implement
new features when I have time to do it, like usual for any open source projects.

If you are student, I will not help you to do your exercises.

If you work on a company, I will not help you to perform simulations.

However if you are interested by a professional support. You can contact my at the address *pyspice*
at my domain name *fabrice-salvaire.fr*
