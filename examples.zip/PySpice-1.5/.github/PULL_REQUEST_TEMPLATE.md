To make it easier to merge your pull request, you should divide your PR into smaller and easier-to-verify units.

Please do not make a pull requests with a lot of modifications which are difficult to check.  If I merge
pull requests blindly then there is a high risk this software will become a mess quickly for everybody.
