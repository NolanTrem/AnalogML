PySpice is an open-source project, and relies on its community of users to keep getting better.

To read further, look at this page https://pyspice.fabrice-salvaire.fr/development.html
